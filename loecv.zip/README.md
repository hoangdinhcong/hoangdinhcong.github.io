# loecv
my personal cv, inspired by simon smith
